# RIG
RIG Exploit Kit (front end)

This repository doesn't contain my code. I have uploaded it to GitHub for those want to analyse the code.

Source: http://www.malwaretech.com/p/sources.html
