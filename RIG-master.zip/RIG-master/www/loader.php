<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>0x43 - Loader</title>
<style type="text/css">
body {
	background-color: #000;
}
body,td,th {
	color: #FFF;
	font-family: Verdana, Geneva, sans-serif;
	font-size: 12px;
}
</style>
</head>

<body link="#FFFFFF" vlink="#FFFFFF" alink="#FF0000">
<center><p><img src=http://i.imgur.com/qERzoGx.png width="709" height="238" /></p>
<p>&nbsp;</p>
<p>
  
  [<a href="./index.php">Home</a>] [<a href="./forums">Community</a>] [<a href="./rig.php">RIG Exploit Kit</a>] [<a href="./silent.php">Silent .Doc Exploit</a>] [<a href="./ubc.php">Universal BTC Stealer</a>] [<a href="#">Unammed Loader</a>] [<a href="./projects.php">Upcoming Projects</a>]</p>
<p>&nbsp;</p></center>
<center>
  <p><strong>Unammed Loader</strong><br />
  </p>
  <p>Conents will be added</p>
</center>
</body>
</html>